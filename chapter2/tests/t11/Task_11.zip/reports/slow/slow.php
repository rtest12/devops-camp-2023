<?php
  sleep(600);
  echo "SLOW REPORT"; 
?>
