<?php
  echo "FAST REPORT";
?>

